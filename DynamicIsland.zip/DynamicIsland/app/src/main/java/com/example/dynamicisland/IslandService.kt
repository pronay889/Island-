package com.example.dynamicisland

import android.accessibilityservice.AccessibilityService
import android.animation.ValueAnimator
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

class IslandService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private lateinit var container: FrameLayout
    private lateinit var pill: LinearLayout
    private lateinit var titleTv: TextView
    private lateinit var subTv: TextView
    private lateinit var params: WindowManager.LayoutParams
    private val bg = GradientDrawable().apply { setColor(Color.BLACK) }
    private val main = Handler(Looper.getMainLooper())
    private var expanded = false
    private var anim: ValueAnimator? = null
    private val collapseRunnable = Runnable { collapse() }

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> applyPrefs() }

    private val powerReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val plugged = i.action == Intent.ACTION_POWER_CONNECTED
            val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
            IslandBus.post(IslandEvent.Charging(level, plugged))
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        titleTv = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 14f; typeface = Typeface.DEFAULT_BOLD
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        }
        subTv = TextView(this).apply {
            setTextColor(0xFFAAAAAA.toInt()); textSize = 12f
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        }
        pill = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), 0, dp(24), 0)
            background = bg
            addView(titleTv); addView(subTv)
            visibility = View.VISIBLE
            setOnClickListener { onTap() }
        }
        titleTv.visibility = View.GONE
        subTv.visibility = View.GONE

        container = FrameLayout(this).apply {
            addView(pill, FrameLayout.LayoutParams(dp(Prefs.get(this@IslandService, Prefs.IDLE_W)),
                dp(Prefs.get(this@IslandService, Prefs.IDLE_H))))
        }

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL }

        applyPrefs()
        wm.addView(container, params)

        Prefs.sp(this).registerOnSharedPreferenceChangeListener(prefListener)
        IslandBus.listener = { handle(it) }

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED); addAction(Intent.ACTION_POWER_DISCONNECTED)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(powerReceiver, f, Context.RECEIVER_EXPORTED)
        else registerReceiver(powerReceiver, f)
    }

    private fun applyPrefs() {
        params.x = dp(Prefs.get(this, Prefs.OFFSET_X))
        params.y = dp(Prefs.get(this, Prefs.OFFSET_Y))
        if (container.isAttachedToWindow) wm.updateViewLayout(container, params)
        if (!expanded) resizePill(dp(Prefs.get(this, Prefs.IDLE_W)), dp(Prefs.get(this, Prefs.IDLE_H)))
    }

    private fun resizePill(w: Int, h: Int) {
        val lp = pill.layoutParams
        lp.width = w; lp.height = h
        pill.layoutParams = lp
        bg.cornerRadius = h / 2f
    }

    private fun animateTo(w: Int, h: Int, end: (() -> Unit)? = null) {
        anim?.cancel()
        val w0 = pill.layoutParams.width; val h0 = pill.layoutParams.height
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 280
            addUpdateListener {
                val t = it.animatedValue as Float
                resizePill((w0 + (w - w0) * t).toInt(), (h0 + (h - h0) * t).toInt())
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: android.animation.Animator) { end?.invoke() }
            })
            start()
        }
    }

    private fun handle(e: IslandEvent) = when (e) {
        is IslandEvent.Notif -> show(e.title, "${e.app} • ${e.text}")
        is IslandEvent.Music -> show("♪ ${e.title}", e.artist)
        is IslandEvent.Charging ->
            if (e.plugged) show("⚡ চার্জ হচ্ছে", "${e.level}%") else show("চার্জার খোলা হয়েছে", "${e.level}%")
    }

    private fun show(title: String, sub: String) {
        main.removeCallbacks(collapseRunnable)
        titleTv.text = title; subTv.text = sub
        titleTv.visibility = View.VISIBLE
        subTv.visibility = if (sub.isBlank()) View.GONE else View.VISIBLE
        expanded = true
        val w = minOf(resources.displayMetrics.widthPixels - dp(24), dp(340))
        animateTo(w, dp(72))
        main.postDelayed(collapseRunnable, 4000)
    }

    private fun collapse() {
        main.removeCallbacks(collapseRunnable)
        titleTv.visibility = View.GONE
        subTv.visibility = View.GONE
        expanded = false
        animateTo(dp(Prefs.get(this, Prefs.IDLE_W)), dp(Prefs.get(this, Prefs.IDLE_H)))
    }

    private fun onTap() {
        if (expanded) collapse() else IslandBus.lastMusic?.let { handle(it) }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        anim?.cancel()
        IslandBus.listener = null
        Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(prefListener)
        try { unregisterReceiver(powerReceiver) } catch (_: Exception) {}
        try { wm.removeView(container) } catch (_: Exception) {}
        super.onDestroy()
    }
}
