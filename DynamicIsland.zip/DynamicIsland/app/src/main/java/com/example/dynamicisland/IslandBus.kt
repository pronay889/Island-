package com.example.dynamicisland

sealed class IslandEvent {
    data class Notif(val app: String, val title: String, val text: String) : IslandEvent()
    data class Music(val title: String, val artist: String) : IslandEvent()
    data class Charging(val level: Int, val plugged: Boolean) : IslandEvent()
}

/** Notification service আর Island service-এর মধ্যে যোগাযোগের সহজ পথ। সব কল main thread-এ আসে। */
object IslandBus {
    var listener: ((IslandEvent) -> Unit)? = null
    var lastMusic: IslandEvent.Music? = null

    fun post(e: IslandEvent) {
        if (e is IslandEvent.Music) lastMusic = e
        listener?.invoke(e)
    }
}
