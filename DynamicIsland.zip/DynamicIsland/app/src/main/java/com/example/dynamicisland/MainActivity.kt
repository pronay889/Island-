package com.example.dynamicisland

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(48), dp(20), dp(32))
        }
        col.addView(TextView(this).apply { text = "Dynamic Island"; textSize = 26f })

        col.addView(section("Step 1: Enable these three settings"))
        col.addView(btn("1. Enable Accessibility") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(btn("2. Grant Notification access") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        col.addView(btn("3. Battery: set to No restriction") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })

        col.addView(section("Step 2: Position (updates live)"))
        col.addView(seek("Distance from top (dp)", Prefs.OFFSET_Y, 0, 60))
        col.addView(seek("Move left/right (dp)", Prefs.OFFSET_X, -150, 150))
        col.addView(seek("Island width (dp)", Prefs.IDLE_W, 20, 200))
        col.addView(seek("Island height (dp)", Prefs.IDLE_H, 16, 60))

        col.addView(section("Look"))
        col.addView(seek("Color", Prefs.COLOR, 0, Prefs.COLOR_NAMES.size - 1, Prefs.COLOR_NAMES))
        col.addView(seek("Text size (sp)", Prefs.TEXT_SIZE, 10, 20))
        col.addView(seek("Expanded width (dp)", Prefs.EXP_W, 200, 360))
        col.addView(seek("Expanded height (dp)", Prefs.EXP_H, 56, 110))

        col.addView(section("Behavior"))
        col.addView(seek("Stay open for (seconds)", Prefs.DURATION, 2, 10))
        col.addView(seek("Animation time (ms, lower = faster)", Prefs.ANIM_MS, 100, 800))

        col.addView(section("Show these events"))
        col.addView(toggle("Charging", Prefs.EV_CHARGE))
        col.addView(toggle("Notifications", Prefs.EV_NOTIF))
        col.addView(toggle("Music", Prefs.EV_MUSIC))

        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun section(t: String) = TextView(this).apply {
        text = t
        textSize = 16f
        setPadding(0, dp(24), 0, dp(4))
    }

    private fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun toggle(label: String, key: String) = Switch(this).apply {
        text = label
        isChecked = Prefs.on(this@MainActivity, key)
        setPadding(0, dp(8), 0, dp(8))
        setOnCheckedChangeListener { _, checked ->
            Prefs.sp(this@MainActivity).edit().putInt(key, if (checked) 1 else 0).apply()
        }
    }

    private fun seek(label: String, key: String, min: Int, max: Int, names: List<String>? = null): LinearLayout {
        val value = Prefs.get(this, key)
        fun txt(v: Int) = "$label: ${names?.getOrNull(v) ?: v}"
        val tv = TextView(this).apply { text = txt(value) }
        val sb = SeekBar(this).apply {
            this.max = max - min
            progress = value - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = p + min
                    tv.text = txt(v)
                    if (fromUser) Prefs.sp(this@MainActivity).edit().putInt(key, v).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, 0)
            addView(tv); addView(sb, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
    }
}
