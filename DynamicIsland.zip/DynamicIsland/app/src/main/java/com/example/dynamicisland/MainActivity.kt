package com.example.dynamicisland

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(48), dp(20), dp(24))
        }
        col.addView(TextView(this).apply { text = "Dynamic Island"; textSize = 26f })
        col.addView(TextView(this).apply {
            text = "ধাপ ১: নিচের তিনটা সেটিংস খুলে চালু করো।"
            setPadding(0, dp(12), 0, dp(8))
        })

        col.addView(btn("১. Accessibility চালু করো") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(btn("২. Notification access দাও") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        col.addView(btn("৩. Battery: No restriction করো") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })

        col.addView(TextView(this).apply {
            text = "ধাপ ২: পজিশন মিলিয়ে নাও (লাইভ বদলাবে)"
            setPadding(0, dp(24), 0, dp(4))
        })
        col.addView(seek("উপর থেকে দূরত্ব (dp)", Prefs.OFFSET_Y, 0, 60))
        col.addView(seek("ডান/বামে সরানো (dp)", Prefs.OFFSET_X, -150, 150))
        col.addView(seek("আইল্যান্ডের প্রস্থ (dp)", Prefs.IDLE_W, 20, 200))
        col.addView(seek("আইল্যান্ডের উচ্চতা (dp)", Prefs.IDLE_H, 16, 60))

        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun seek(label: String, key: String, min: Int, max: Int): LinearLayout {
        val value = Prefs.get(this, key)
        val tv = TextView(this).apply { text = "$label: $value" }
        val sb = SeekBar(this).apply {
            this.max = max - min
            progress = value - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = p + min
                    tv.text = "$label: $v"
                    if (fromUser) Prefs.sp(this@MainActivity).edit().putInt(key, v).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, 0)
            addView(tv); addView(sb, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
    }
}
