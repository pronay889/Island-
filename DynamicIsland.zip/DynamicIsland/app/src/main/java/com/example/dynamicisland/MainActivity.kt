package com.example.dynamicisland

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(48), dp(20), dp(24))
        }
        col.addView(TextView(this).apply { text = "Dynamic Island"; textSize = 26f })
        col.addView(TextView(this).apply {
            text = "Step 1: Open these three settings and enable them."
            setPadding(0, dp(12), 0, dp(8))
        })

        col.addView(btn("1. Enable Accessibility") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(btn("2. Grant Notification access") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        col.addView(btn("3. Battery: set to No restriction") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })

        col.addView(TextView(this).apply {
            text = "Step 2: Adjust position (updates live)"
            setPadding(0, dp(24), 0, dp(4))
        })
        col.addView(seek("Distance from top (dp)", Prefs.OFFSET_Y, 0, 60))
        col.addView(seek("Move left/right (dp)", Prefs.OFFSET_X, -150, 150))
        col.addView(seek("Island width (dp)", Prefs.IDLE_W, 20, 200))
        col.addView(seek("Island height (dp)", Prefs.IDLE_H, 16, 60))

        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun seek(label: String, key: String, min: Int, max: Int): LinearLayout {
        val value = Prefs.get(this, key)
        val tv = TextView(this).apply { text = "$label: $value" }
        val sb = SeekBar(this).apply {
            this.max = max - min
            progress = value - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = p + min
                    tv.text = "$label: $v"
                    if (fromUser) Prefs.sp(this@MainActivity).edit().putInt(key, v).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, 0)
            addView(tv); addView(sb, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
    }
}
