package com.example.dynamicisland

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color

object Prefs {
    const val OFFSET_Y = "offset_y"
    const val OFFSET_X = "offset_x"
    const val IDLE_W = "idle_w"
    const val IDLE_H = "idle_h"
    const val COLOR = "color"
    const val TEXT_SIZE = "text_size"
    const val DURATION = "duration"
    const val ANIM_MS = "anim_ms"
    const val EXP_W = "exp_w"
    const val EXP_H = "exp_h"
    const val EV_CHARGE = "ev_charge"
    const val EV_NOTIF = "ev_notif"
    const val EV_MUSIC = "ev_music"

    val COLOR_NAMES = listOf("Black", "Dark gray", "Deep blue", "Purple", "Green", "Red")
    private val COLORS = intArrayOf(
        Color.BLACK, 0xFF1C1C1E.toInt(), 0xFF0A1F44.toInt(),
        0xFF2A1048.toInt(), 0xFF0B2E1F.toInt(), 0xFF3A0D0D.toInt()
    )

    fun sp(c: Context): SharedPreferences = c.getSharedPreferences("island", Context.MODE_PRIVATE)

    fun default(key: String) = when (key) {
        OFFSET_Y -> 8
        OFFSET_X -> 0
        IDLE_W -> 110
        IDLE_H -> 30
        COLOR -> 0
        TEXT_SIZE -> 14
        DURATION -> 4
        ANIM_MS -> 280
        EXP_W -> 340
        EXP_H -> 72
        else -> 1 // events on
    }

    fun get(c: Context, key: String) = sp(c).getInt(key, default(key))
    fun on(c: Context, key: String) = get(c, key) == 1
    fun color(c: Context) = COLORS[get(c, COLOR).coerceIn(0, COLORS.size - 1)]
}
