package com.example.dynamicisland

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val OFFSET_Y = "offset_y"   // dp, উপর থেকে দূরত্ব
    const val OFFSET_X = "offset_x"   // dp, মাঝ থেকে ডানে/বামে (ঋণাত্মক = বামে)
    const val IDLE_W = "idle_w"       // dp
    const val IDLE_H = "idle_h"       // dp

    fun sp(c: Context): SharedPreferences = c.getSharedPreferences("island", Context.MODE_PRIVATE)

    fun default(key: String) = when (key) {
        OFFSET_Y -> 8
        OFFSET_X -> 0
        IDLE_W -> 110
        else -> 30
    }

    fun get(c: Context, key: String) = sp(c).getInt(key, default(key))
}
